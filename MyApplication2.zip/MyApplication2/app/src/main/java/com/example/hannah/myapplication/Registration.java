package com.example.hannah.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Button buttonNextRegistration = (Button)findViewById(R.id.btn_next_signup);
        final EditText nameUser = (EditText) findViewById(R.id.input_first_name);
        buttonNextRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(Registration.this, Registration2.class);
                myIntent.putExtra("FIRST_NAME_USER",nameUser.getText().toString());
                startActivity(myIntent);
            }
        });

        Button buttonPrevRegistration = (Button)findViewById(R.id.btn_prev_signup);
        buttonPrevRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registration.this,LoginActivity.class));
            }
        });
    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_homme:
                if (checked)
                    // Pirates are the best
                    break;
            case R.id.radio_femme:
                if (checked)
                    // Ninjas rule
                    break;
        }
    }
}
