package com.example.hannah.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class Registration2 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration2);
        Bundle extras = getIntent().getExtras();
        final String firstNameUser = extras.getString("FIRST_NAME_USER");

        Button buttonCancelRegistration = (Button)findViewById(R.id.btn_cancel_signup);
        buttonCancelRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registration2.this,LoginActivity.class));
            }
        });
        Button buttonFinishRegistration = (Button)findViewById(R.id.btn_finish_signUp);
        //REDIRECT TO MENU ACTIVITY !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        buttonFinishRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Registration2.this, firstNameUser + " ,bienvenue chez Band With Us !" ,
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Registration2.this,LoginActivity.class));
            }
        });





        //INSTRUMENTS STYLE ADAPTER
        final Spinner spinner = (Spinner) findViewById(R.id.spinnerInstruments);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.spinnerInstruments, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(spinnerAdapter);
        Button instrumentAdd = (Button) findViewById(R.id.addButtonInstrument);
        final ListView listViewInstruments = (ListView) findViewById(R.id.listInstruments);
        final ArrayList<String> listItems = new ArrayList<String>();
        final ArrayAdapter<String> listInstrumentsAdapter = new ArrayAdapter<String>(Registration2.this, android.R.layout.simple_list_item_1,listItems );
        listViewInstruments.setAdapter(listInstrumentsAdapter);
        instrumentAdd.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                listItems.add(spinner.getSelectedItem().toString());
                listInstrumentsAdapter.notifyDataSetChanged();
            }
        });


        //SPINNER STYLE ADAPTER
        final Spinner spinnerStyle = (Spinner) findViewById(R.id.spinnerStyle);
        ArrayAdapter<CharSequence> spinnerStyleAdapter = ArrayAdapter.createFromResource(this,
                R.array.spinnerStyle, android.R.layout.simple_spinner_item);
        spinnerStyleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStyle.setAdapter(spinnerStyleAdapter);
        Button styleAdd = (Button) findViewById(R.id.addButtonStyle);
        final ListView listViewStyle = (ListView) findViewById(R.id.listStyle);
        final ArrayList<String> listItems1 = new ArrayList<String>();
        final ArrayAdapter<String> listStyleAdapter = new ArrayAdapter<String>(Registration2.this, android.R.layout.simple_list_item_1,listItems1 );
        listViewStyle.setAdapter(listStyleAdapter);
        styleAdd.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                listItems1.add(spinnerStyle.getSelectedItem().toString());
                listStyleAdapter.notifyDataSetChanged();
            }
        });





    }


}
